#!/usr/bin/env python3
import argparse
import json
import sys
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError


ENDPOINT = "https://chatgpt.com/backend-api/wham/rate-limit-reset-credits"


def fail(message, code=1):
    print(message, file=sys.stderr)
    raise SystemExit(code)


def parse_time(value):
    if not value:
        return None
    if not isinstance(value, str):
        value = str(value)
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def format_time(value, tz):
    dt = parse_time(value)
    if not dt:
        return "not set" if not value else str(value)
    return dt.astimezone(tz).strftime("%Y-%m-%d %H:%M:%S %Z")


def pick(obj, names):
    for name in names:
        value = obj.get(name)
        if value:
            return value
    return None


def duration_until(value, tz):
    dt = parse_time(value)
    if not dt:
        return "unknown"
    now = datetime.now(timezone.utc)
    seconds = int((dt.astimezone(timezone.utc) - now).total_seconds())
    prefix = "" if seconds >= 0 else "expired "
    seconds = abs(seconds)
    days, rem = divmod(seconds, 86400)
    hours, rem = divmod(rem, 3600)
    minutes, _ = divmod(rem, 60)
    if days:
        return f"{prefix}{days}d {hours}h {minutes}m"
    if hours:
        return f"{prefix}{hours}h {minutes}m"
    return f"{prefix}{minutes}m"


def load_auth(auth_path):
    if not auth_path.exists():
        fail(f"Codex auth file not found: {auth_path}")
    try:
        auth = json.loads(auth_path.read_text(encoding="utf-8"))
    except Exception as exc:
        fail(f"Could not read Codex auth file: {exc}")
    tokens = auth.get("tokens") or {}
    access_token = tokens.get("access_token")
    if not access_token:
        fail("No access_token found in Codex auth file. Log in to Codex again, then retry.")
    return tokens


def fetch_payload(tokens):
    headers = {
        "Authorization": f"Bearer {tokens['access_token']}",
        "OpenAI-Beta": "codex-1",
        "originator": "Codex Desktop",
        "User-Agent": "Codex Desktop",
        "Accept": "application/json",
    }
    if tokens.get("account_id"):
        headers["ChatGPT-Account-ID"] = tokens["account_id"]

    request = urllib.request.Request(ENDPOINT, headers=headers)
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            raw = response.read().decode("utf-8", errors="replace")
            return response.status, json.loads(raw)
    except urllib.error.HTTPError as exc:
        exc.read()
        return exc.code, {"error": "redacted"}
    except urllib.error.URLError as exc:
        fail(f"Request failed: {exc}")
    except json.JSONDecodeError as exc:
        fail(f"Endpoint returned non-JSON data: {exc}")


def main():
    parser = argparse.ArgumentParser(description="Check Codex banked reset credit expiry times.")
    parser.add_argument("--timezone", default="Asia/Shanghai", help="IANA timezone for output times.")
    parser.add_argument(
        "--auth-path",
        default=str(Path.home() / ".codex" / "auth.json"),
        help="Path to Codex auth.json. Defaults to ~/.codex/auth.json.",
    )
    args = parser.parse_args()

    try:
        tz = ZoneInfo(args.timezone)
    except ZoneInfoNotFoundError:
        fail(f"Unknown timezone: {args.timezone}")

    tokens = load_auth(Path(args.auth_path).expanduser())
    status, payload = fetch_payload(tokens)

    print(f"HTTP status: {status}")
    if status != 200:
        print("Could not query reset credits.")
        if status in (401, 403):
            print("The Codex login may be stale or this internal endpoint is not available to this account.")
        raise SystemExit(1)

    if not isinstance(payload, dict):
        print("Unexpected response shape.")
        raise SystemExit(1)

    credits = payload.get("credits") or payload.get("items") or payload.get("data") or []
    print(f"available_count: {payload.get('available_count', payload.get('availableCount', 'not set'))}")
    print(f"total_earned_count: {payload.get('total_earned_count', payload.get('totalEarnedCount', 'not set'))}")
    print(f"credits_count: {len(credits) if isinstance(credits, list) else 'not a list'}")

    if not isinstance(credits, list):
        raise SystemExit(0)

    for index, credit in enumerate(credits, start=1):
        if not isinstance(credit, dict):
            print(f"\nCredit #{index}: unexpected item")
            continue
        credit_type = pick(credit, ["reset_type", "type", "credit_type", "creditType"]) or "unknown"
        status_value = pick(credit, ["status", "state"]) or "unknown"
        effective_at = pick(
            credit,
            ["starts_at", "startsAt", "effective_at", "effectiveAt", "granted_at", "grantedAt", "created_at", "createdAt"],
        )
        expires_at = pick(credit, ["expires_at", "expiresAt", "expiration_at", "expirationAt"])
        used_at = pick(credit, ["used_at", "usedAt", "redeemed_at", "redeemedAt", "redeem_started_at", "redeemStartedAt"])

        print(f"\nCredit #{index}")
        print(f"  type: {credit_type}")
        print(f"  status: {status_value}")
        print(f"  effective/created: {format_time(effective_at, tz)}")
        print(f"  expires: {format_time(expires_at, tz)}")
        print(f"  remaining: {duration_until(expires_at, tz)}")
        if used_at:
            print(f"  used/redeem started: {format_time(used_at, tz)}")


if __name__ == "__main__":
    main()
