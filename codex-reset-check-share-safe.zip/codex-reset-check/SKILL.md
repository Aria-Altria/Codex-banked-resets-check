---
name: codex-reset-check
description: Check Codex banked reset credits/cards and their validity or expiry times. Use when the user asks to inspect Codex reset cards, reset card expiration, reset card validity, how long resets have left, check banked resets, banked resets check, resets check, rate-limit reset credits, Codex reset credits, 重置卡时效, 重置卡是否有效, 重置卡什么时候过期, 重置卡还有多久过期, 检查重置卡, 查询重置卡, or similar prompts.
---

# Codex Reset Check

## Workflow

Use the bundled script for the actual query:

```powershell
python "$HOME\.codex\skills\codex-reset-check\scripts\check_reset_credits.py"
```

The script reads `~/.codex/auth.json`, calls the read-only internal endpoint
`https://chatgpt.com/backend-api/wham/rate-limit-reset-credits`, and prints only
sanitized reset credit details. Do not print or reveal access tokens, refresh
tokens, `auth.json`, credit ids, profile ids, or raw response bodies unless the
user explicitly needs debugging and sensitive fields are redacted first.

## Output

Report:

- HTTP/query success or the actionable failure reason.
- `available_count` and total returned credit count.
- For each credit: status, type, created/effective time, expiry time, and time remaining.

Treat `created_at` as the effective or grant time when the API does not return
`granted_at`, `starts_at`, or `effective_at`. The API is internal and may change;
if it returns `401`, `403`, or unexpected fields, explain that the product UI or
OpenAI Support may be the only current source of truth.

The default timezone is `Asia/Shanghai`. If the user asks for another timezone,
pass it with `--timezone`, for example:

```powershell
python "$HOME\.codex\skills\codex-reset-check\scripts\check_reset_credits.py" --timezone America/Los_Angeles
```
